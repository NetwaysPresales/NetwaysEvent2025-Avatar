export { AvatarPage } from './AvatarPage';

